## Whatsapp Bot With Some Unique Features but it can running with termux
[`whatsapp-web.js`](https://github.com/pedrolopez/whatsapp-web.js)
![Fork](https://img.shields.io/github/forks/mhankbarbar/termux-whatsapp-bot?style=social)


This is a bot , sure this is a bot ! 

## Getting Started

This project require MQTT broker, nodeJS.

### Install

make sure u have installed ubuntu 18.04 in your termux , if you aren't install it 
go install an Apps called *Andronix* on google play 
until you have ubuntu like this


then ..
Clone this project

```zsh
> git clone https://github.com/mhankbarbar/termux-whatsapp-bot
> cd termux-whatsapp-bot

```

Install the dependencies:

```zsh
> npm i
```



### Usage
run the Whatsapp bot

```zsh
> npm start
```

after running it you need to scan the qr

### Features
Type !menu or !help for show feature

Feature | Status |
| -------------- | ------------- |
| Instagram download | Oke |
| WhatsAnime | Oke |
| Brainly | Oke |
| Text to voivce | Oke |
| Nhentai | Oke |
| Horoscope menu | Oke |
| And | Others |

### Owner Commands
( Only owner group! )

› `!promote`: Menaikkan pangkat member menjadi admin<br>
› `!demote`: Menurunkan pangkat admin menjadi member<br>
› `!kick`: Mengeluarkan member group<br>
› `!add`: Menambahkan member group<br>
› `!deskripsi`: Mengubah desc group<br>
› `!subject`: Mengubah title group
